package com.softeem.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig {
    @Bean
    WebMvcConfigurer webMvcConfigurer()
    {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedHeaders("*")            // 允许请求头
                        .allowedMethods("GET","POST","OPTIONS","PUT","DELETE")
                        .allowedOrigins("*")            // 源，可以是多个地址，用逗号隔开
                        .maxAge(3600);                  // 时间内允许跨域
            }
        };
    }
}
