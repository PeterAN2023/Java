package com.softeem.config;

import com.softeem.util.Result;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice // = @ControllerAdice + @ResponseBody 用于指定异常处理方法，全局处理控制器的异常
// @RestControllerAdvice(basePackages = {"com.softeem.controller"})  指定一个或多个包
// @RestControllerAdvice(basePackageClasses = {AwardController.class}) 指定一个或多个Controller类 ,这些类所属的包及其子包的所有Controller
// @RestControllerAdvice(assignableTypes = { AwardController.class })   指定一个或多个Controller类
// @RestControllerAdvice(annotations = { AwardController.class })  指定一个或多个注解
public class GlobalExceptionHandle {

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public Result exceptionHandle(Exception ex) {
        return Result.buildError(ex.getMessage());
    }
}
