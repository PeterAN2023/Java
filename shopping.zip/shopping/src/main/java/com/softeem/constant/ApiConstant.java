package com.softeem.constant;

public class ApiConstant {
    public static final int SUCCESS = 1;
    public static final int ERROR = 0;
    public static final int WARNING = 2;
}
