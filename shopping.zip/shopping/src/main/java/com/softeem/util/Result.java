package com.softeem.util;

import com.softeem.constant.ApiConstant;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Result<T> {
    private Integer code;
    private String message;
    private T data;

    public static <T> Result<T> build(Integer code,String message,T data)
    {
        if(code == null)
        {
            code = ApiConstant.SUCCESS;
        }
        Result result = new Result();
        result.setCode(code);
        result.setMessage(message);
        result.setData(data);
        return  result;
    }

    public static <T> Result<T> buildSuccess(){
        return build(ApiConstant.SUCCESS,null,null);
    }

    public static <T> Result<T> buildSuccess(T data){
        return build(ApiConstant.SUCCESS,null,data);
    }

    public static <T> Result<T> buildError(String message){
        return build(ApiConstant.ERROR,message,null);
    }

}
