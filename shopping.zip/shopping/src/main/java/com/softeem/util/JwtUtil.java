package com.softeem.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;

import java.time.Duration;
import java.util.Date;

@Slf4j
public class JwtUtil {

    private static final String SECRET_KEY = "KObMkR0eJ6F7l1mynUe/rKDEbK5XVoCeOGlyQLU6YBKFPkMcp0XiFelTJ2kJD+GE6f8pfQ3R2hIiTBvCbDUh+GTgM8GxtIqtNVg8oD7R8rAlZWWgRw";
//    private static final String SECRET_KEY = "softeem";
    private static final Duration exp = Duration.ofHours(2);

    public static String generate(String username) {
        return Jwts.builder()
                .setIssuedAt(new Date())
                .setSubject(username)
                .setExpiration(new Date(System.currentTimeMillis() + exp.toMillis()))
                .signWith(SignatureAlgorithm.HS512, SECRET_KEY)
                .compact();
    }


    public static Claims parse(String token) {
        if (token == null) {
            log.error("token is null!!");
            return null;
        }
        Claims claims = null;
        try {
            claims = Jwts.parser().
                    setSigningKey(SECRET_KEY).
                    parseClaimsJws(token).
                    getBody();
        } catch (Exception ex) {
            log.error("ex: [{}]", ex.getMessage());
        }
        return claims;


    }

}
