package com.softeem.util;

import com.softeem.constant.ApiConstant;
import lombok.Getter;
import lombok.Setter;

// 异常处理类
@Getter
@Setter
public class ParameterException extends RuntimeException {
    // 错误编码
    private Integer errorCode;

    public ParameterException(){
        super();
        this.errorCode = ApiConstant.ERROR;
    }

    public ParameterException(Integer errorCode){
        super();
        this.errorCode = errorCode;
    }


    public ParameterException(String message){
        super(message);
        this.errorCode = ApiConstant.ERROR;
    }

    public ParameterException(Integer errorCode, String message){
        super(message);
        this.errorCode = errorCode;
    }
}
