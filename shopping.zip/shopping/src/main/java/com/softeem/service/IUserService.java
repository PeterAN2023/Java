package com.softeem.service;

import com.softeem.entity.User;

import java.util.List;

public interface IUserService {

//    List<User> findUser();

    String login(User user);
}
