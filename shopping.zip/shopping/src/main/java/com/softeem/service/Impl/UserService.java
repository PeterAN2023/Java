package com.softeem.service.impl;

import com.softeem.entity.User;
import com.softeem.mapper.UserMapper;
import com.softeem.service.IUserService;
import com.softeem.util.JwtUtil;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

@Service
public class UserService implements IUserService {

    @Resource
    private UserMapper userMapper;

    @Resource
    private AuthenticationManager authenticationManager;

//    @Override
//    public List<User> findUser() {
//        return userMapper.findUsers();
//    }

    @Override
    public String login(User user) {
        /**
         * 1. Authentication:  状态 = 已认证
         * 2. SecurityContext.setAuthentication()
         */
        /// 委托AuthenticationManager完成认证流程，需要提供用户的加载方式和密码的校验方式
        Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                user.getUsername(),
                user.getPassword()
        ));
        SecurityContextHolder.getContext().setAuthentication(authenticate);
        return JwtUtil.generate(user.getUsername());
    }
}
