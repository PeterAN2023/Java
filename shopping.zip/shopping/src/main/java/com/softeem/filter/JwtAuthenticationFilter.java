package com.softeem.filter;


import cn.hutool.core.util.StrUtil;
import com.softeem.entity.Permission;
import com.softeem.mapper.PermissionMapper;
import com.softeem.util.JwtUtil;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerExceptionResolver;

import javax.annotation.Resource;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class JwtAuthenticationFilter implements Filter {
    @Resource
    PermissionMapper permissionMapper;

    // 全局异常通知对象
    // IOC中存在，直接注入即可使用
    @Resource
    @Qualifier("handlerExceptionResolver")
    HandlerExceptionResolver exceptionResolver;

    // throw new RuntimeException();  //
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;

        if (request.getRequestURI().contains("/login")) {
            filterChain.doFilter(request, response);
            return;
        }

        // 获取请求头中的凭证
        String token = request.getHeader("token");
        if (StrUtil.isBlank(token)) {
            //throw xxxException();// 立即中断程序，向外抛出异常--》xxx--xx--》虚拟机
            exceptionResolver.resolveException(
                    request, (HttpServletResponse) response, null, new BadCredentialsException("凭证不可为空")
            );
            return;
        }
        log.info("token: [{}]", token);
        /// 解析凭证
        Claims body = JwtUtil.parse(token);
        if (body == null) {
            exceptionResolver.resolveException(
                    request, (HttpServletResponse) response, null, new BadCredentialsException("凭证已过期，或已经被篡改")
            );
            return;
        }
        // 加载用户权限

        List<SimpleGrantedAuthority> authorities = permissionMapper.findPermissionByUsername(body.getSubject())
                .stream().map(Permission::getPName).collect(Collectors.toList())
                .stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
        log.info("authrites: [{}]", authorities.size());
        // Security上下文处理
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(
                        body.getSubject(),
                        null,
                        authorities
                )
        );
        filterChain.doFilter(request, response);
    }
}
