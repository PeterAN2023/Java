package com.softeem.mapper;

import com.softeem.entity.Permission;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface PermissionMapper {

    // 根据当前用户查询用户的所有权限
    @Select("SELECT * FROM PERMISSION " +
            "WHERE PID " +
            "IN " +
            "(SELECT PID FROM role_permission WHERE RID IN( " +
            "SELECT RID FROM USER_ROLE WHERE UID " +
            "=(SELECT ID FROM USER WHERE USERNAME =#{username}) " +
            "))")
    List<Permission> findPermissionByUsername(String username);
}
