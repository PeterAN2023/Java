package com.softeem.controller;

import com.softeem.entity.User;
import com.softeem.service.IUserService;
import com.softeem.util.Result;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.security.core.parameters.P;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;

@RestController
@RequestMapping("/user")
public class UserController {

    @Resource
    private IUserService userService;

    @PostMapping("/login")
    public String login(@RequestBody User user) {
        return userService.login(user);
    }

//    @PostMapping("/login")
//    public Result doLogin(String userCode, String password) {
//        String token = userService.login(userCode, password);
//
//        if (token == null || token.isEmpty()) {
//            return Result.buildError("登录失败");
//        } else {
//            return Result.buildSuccess(token);
//        }
//    }
}
